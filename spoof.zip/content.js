// content.js - Shield + Receiver (MAIN World)

(function() {
    // --- STEP 1: INSTANT SHIELD (Leak Rokne Ke Liye) ---
    // Jab tak storage se data aaye, tab tak Pixel 8 Pro ko chhupa ke rakho
    try {
        // UserAgentData ko maar do
        Object.defineProperty(navigator, 'userAgentData', { get: () => undefined });
        
        // GPU ko generic bana do
        const getParam = WebGLRenderingContext.prototype.getParameter;
        WebGLRenderingContext.prototype.getParameter = function(p) {
            if (p === 37445) return "Google Inc."; 
            if (p === 37446) return "Generic GPU"; 
            return getParam.apply(this, arguments);
        };
    } catch (e) {}


    // --- STEP 2: RECEIVE DATA (Device Change Karne Ke Liye) ---
    window.addEventListener('SPOOF_DATA_READY', function(e) {
        const device = JSON.parse(e.detail);
        console.log("Applying Device: " + device.name);

        try {
            // A. Update Navigator (UA, Platform, etc)
            Object.defineProperties(navigator, {
                userAgent: { get: () => device.ua },
                platform: { get: () => device.platform },
                hardwareConcurrency: { get: () => device.cores },
                deviceMemory: { get: () => device.memory },
                maxTouchPoints: { get: () => 5 }
            });

            // B. Update Screen
            Object.defineProperty(window, 'devicePixelRatio', { get: () => device.scale });
            const screenProps = {
                width: { get: () => device.width },
                height: { get: () => device.height },
                availWidth: { get: () => device.width },
                availHeight: { get: () => device.height },
            };
            Object.defineProperties(screen, screenProps);

            // C. Update GPU (Specific Vendor/Renderer)
            const spoofWebGL = (context) => {
                const proto = window[context].prototype;
                const oldParam = proto.getParameter;
                proto.getParameter = function(p) {
                    if (p === 37445) return device.vendor;
                    if (p === 37446) return device.renderer;
                    return oldParam.apply(this, arguments);
                };
            };
            if (window.WebGLRenderingContext) spoofWebGL("WebGLRenderingContext");
            if (window.WebGL2RenderingContext) spoofWebGL("WebGL2RenderingContext");

            // D. Fix UserAgentData (Agar Android hai to wapis laao, agar iPhone hai to undefined rakho)
            if (device.ch_platform === "Android") {
                 // Android ke liye fake UA Data banao (Advanced)
                 // Filhal undefined rakhna sabse safe hai taaki leak na ho.
                 // Agar aapko Android specific headers chahiye to bataiyega.
            }

        } catch (err) { console.error(err); }
    });

})();
