const select = document.getElementById('deviceSelect');
const btn = document.getElementById('applyBtn');
const statusMsg = document.getElementById('statusMsg');

// Populate Dropdown
devices.forEach(device => {
  const option = document.createElement('option');
  option.value = device.id;
  option.textContent = device.name;
  select.appendChild(option);
});

// Load Saved State
chrome.storage.local.get(['selectedDeviceId'], (result) => {
  if (result.selectedDeviceId) {
    select.value = result.selectedDeviceId;
    statusMsg.textContent = "Active: " + devices.find(d => d.id === result.selectedDeviceId).name;
  }
});

// Save and Apply
btn.addEventListener('click', () => {
  const selectedId = select.value;
  const selectedDevice = devices.find(d => d.id === selectedId);

  chrome.storage.local.set({ 
      selectedDeviceId: selectedId,
      selectedDeviceObject: selectedDevice 
  }, () => {
      statusMsg.textContent = "Active: " + selectedDevice.name;
      // Refresh the current tab to apply changes
      chrome.tabs.query({active: true, currentWindow: true}, (tabs) => {
          if(tabs[0]) chrome.tabs.reload(tabs[0].id);
      });
  });
});
