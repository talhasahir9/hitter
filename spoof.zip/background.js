importScripts('devices.js');
let currentDevice = devices[0];

chrome.storage.local.get(['selectedDeviceObject'], (data) => {
    if (data.selectedDeviceObject) currentDevice = data.selectedDeviceObject;
    updateHeaders();
});

chrome.storage.onChanged.addListener((changes) => {
    if (changes.selectedDeviceObject) {
        currentDevice = changes.selectedDeviceObject.newValue;
        updateHeaders();
    }
});

function updateHeaders() {
    const rules = [{
        "id": 1,
        "priority": 1,
        "action": {
            "type": "modifyHeaders",
            "requestHeaders": [
                { "header": "User-Agent", "operation": "set", "value": currentDevice.ua },
                { "header": "Sec-CH-UA-Model", "operation": "remove" },
                { "header": "Sec-CH-UA-Platform", "operation": "remove" },
                { "header": "Sec-CH-UA-Mobile", "operation": "remove" },
                { "header": "Sec-CH-UA", "operation": "remove" },
                { "header": "Sec-CH-UA-Full-Version-List", "operation": "remove" }
            ]
        },
        "condition": { "urlFilter": "*", "resourceTypes": ["main_frame", "sub_frame", "xmlhttprequest"] }
    }];

    chrome.declarativeNetRequest.updateDynamicRules({
        removeRuleIds: [1],
        addRules: rules
    });
}
