// Is file ko popup.js aur background.js dono mein use karenge
const devices = [
  {
    id: "iphone15pro",
    name: "Apple iPhone 15 Pro",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
    platform: "iPhone",
    vendor: "Apple Computer, Inc.",
    renderer: "Apple GPU",
    ch_platform: "iOS",
    ch_mobile: "?1",
    ch_model: "iPhone 15 Pro",
    width: 393, height: 852, scale: 3, cores: 6, memory: 8
  },
  {
    id: "s24ultra",
    name: "Samsung Galaxy S24 Ultra",
    ua: "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.101 Mobile Safari/537.36",
    platform: "Linux armv81",
    vendor: "Google Inc. (Qualcomm)",
    renderer: "Adreno (TM) 750",
    ch_platform: "Android",
    ch_mobile: "?1",
    ch_model: "SM-S928B",
    width: 412, height: 915, scale: 3.5, cores: 8, memory: 12
  },
  {
    id: "pixel8pro",
    name: "Google Pixel 8 Pro",
    ua: "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.6167.101 Mobile Safari/537.36",
    platform: "Linux armv81",
    vendor: "Google Inc. (ARM)",
    renderer: "Mali-G715",
    ch_platform: "Android",
    ch_mobile: "?1",
    ch_model: "Pixel 8 Pro",
    width: 412, height: 915, scale: 3, cores: 8, memory: 12
  },
  {
    id: "ipadpro_m4",
    name: "iPad Pro (M4) 13-inch",
    ua: "Mozilla/5.0 (iPad; CPU OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1",
    platform: "iPad",
    vendor: "Apple Computer, Inc.",
    renderer: "Apple GPU",
    ch_platform: "iOS",
    ch_mobile: "?1", // iPads often request desktop sites, but for app testing ?1 is safer
    ch_model: "iPad",
    width: 1024, height: 1366, scale: 2, cores: 8, memory: 16
  },
  {
    id: "xiaomi14",
    name: "Xiaomi 14 Pro",
    ua: "Mozilla/5.0 (Linux; Android 14; 23116PN5BC) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.193 Mobile Safari/537.36",
    platform: "Linux armv81",
    vendor: "Google Inc. (Qualcomm)",
    renderer: "Adreno (TM) 750",
    ch_platform: "Android",
    ch_mobile: "?1",
    ch_model: "23116PN5BC",
    width: 393, height: 873, scale: 3, cores: 8, memory: 12
  },
    {
    id: "oneplus12",
    name: "OnePlus 12",
    ua: "Mozilla/5.0 (Linux; Android 14; CPH2581) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.6099.210 Mobile Safari/537.36",
    platform: "Linux armv81",
    vendor: "Google Inc. (Qualcomm)",
    renderer: "Adreno (TM) 750",
    ch_platform: "Android",
    ch_mobile: "?1",
    ch_model: "CPH2581",
    width: 412, height: 919, scale: 3, cores: 8, memory: 16
  },
  {
    id: "iphone13",
    name: "Apple iPhone 13",
    ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
    platform: "iPhone",
    vendor: "Apple Computer, Inc.",
    renderer: "Apple GPU",
    ch_platform: "iOS",
    ch_mobile: "?1",
    ch_model: "iPhone 13",
    width: 390, height: 844, scale: 3, cores: 6, memory: 4
  },
  {
    id: "galaxy_a54",
    name: "Samsung Galaxy A54 5G",
    ua: "Mozilla/5.0 (Linux; Android 13; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Mobile Safari/537.36",
    platform: "Linux armv81",
    vendor: "Google Inc. (ARM)",
    renderer: "Mali-G68",
    ch_platform: "Android",
    ch_mobile: "?1",
    ch_model: "SM-A546B",
    width: 412, height: 915, scale: 2.5, cores: 8, memory: 6
  }
];
