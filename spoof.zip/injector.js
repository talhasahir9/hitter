// injector.js - The Data Bridge

// 1. Storage se user ka select kiya hua device laao
chrome.storage.local.get(['selectedDeviceObject'], function(data) {
    let device = data.selectedDeviceObject;
    
    // Agar koi device select nahi hai, to Default (iPhone) bhejo
    if (!device) {
        device = {
            ua: "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
            platform: "iPhone",
            vendor: "Apple Computer, Inc.",
            renderer: "Apple GPU",
            name: "Default iPhone"
        };
    }

    // 2. Data ko string banao aur 'content.js' ko bhejo
    // Hum "CustomEvent" use kar rahe hain kyunki ye walls ke aar-paar ja sakta hai
    const event = new CustomEvent('SPOOF_DATA_READY', { 
        detail: JSON.stringify(device) 
    });
    window.dispatchEvent(event);
});
